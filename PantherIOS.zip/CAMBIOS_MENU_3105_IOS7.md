# IOS !7 — navegación al menú 3105

- Después del login, la pantalla principal muestra FF MAX y FF NORMAL.
- Ambos botones abren la misma pantalla de demostración "FUNÇÕES DO 3105".
- Incluye pestañas AIMBOT y TEXTURAS y controles visuales locales.
- Los interruptores son únicamente de demostración: no alteran Free Fire, no aplican parches ni implementan aimbot o trampas.
- El botón Volver regresa al selector de juego.
- El botón Abrir Free Fire es solo visual en esta versión; no se configuró un esquema de URL porque el paquete instalado puede variar.

Archivo modificado: ThreeOneOSFive/ContentView.swift
